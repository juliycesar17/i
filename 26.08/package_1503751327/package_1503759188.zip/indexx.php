<?php


$ar = array('apple', 'orange', 1, false, null, true, 3 + 5);
echo json_encode($ar) ;
?>