Handlebars.registerHelper('if_eq', function() {
   
    
	 console.log(this);
	   
	   
});