function cartModel(items, model) {
	 this._model = model;
	this._model.itemAddedtocartyes.attached(
	
	
	);
	
	
	
	
}