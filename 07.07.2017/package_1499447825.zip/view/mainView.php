<script id="index" type="text/x-handlebars-template" >
  <!-- First Photo Grid МОРОЖЕНОЕ-->
 <div class="w3-container w3-red w3-center w3-padding-128">
  <h1 class="w3-margin w3-jumbo">{{ice}}</h1>
  <p class="w3-xlarge">ПОКУПАЙ КАЧЕСТВЕННЫЙ ПРОДУКТ</p>
  <button hh="dog_main.php" class="dog_main w3-btn w3-padding-16 w3-large w3-margin-top ">ВПЕРЕД</button>
</div>

  <!-- Footer -->

</script>
