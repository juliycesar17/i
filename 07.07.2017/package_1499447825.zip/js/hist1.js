history.pushState('http://www.joyforchild.com/ice/dog_main.php', document.title, 'http://www.joyforchild.com/shop');
