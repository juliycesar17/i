
function check () {
 if($("#fff").length > 0){
	 $('#fff').remove();}
	  if($("form").length > 0){
	 $('form').remove();}
	 if($("#blog_inner").length > 0){
	 $("#blog_inner").remove();}
	  if($("#templ_for_recipe").length > 0){
	 $('#templ_for_recipe').remove();}
	  if($("#ccc").length > 0){
	 $('#ccc').remove();}
	  if($("#ggg").length > 0){
	 $('#ggg').remove();}
 if  ($('[class~=aaa]').length > 0) {$('[class~=aaa]').remove();}	
  if ($(".aaa").length > 0){
    $('.aaa').remove();}
  if ( $('.w3-padding-128').length> 0 ){$('.w3-padding-128').remove();}
}

